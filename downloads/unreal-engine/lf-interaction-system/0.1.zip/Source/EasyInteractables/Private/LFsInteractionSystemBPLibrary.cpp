// All Rights Reserved - LFInteractive LLC (c) 2022

#include "LFsInteractionSystemBPLibrary.h"
#include "LFsInteractionSystem.h"

ULFsInteractionSystemBPLibrary::ULFsInteractionSystemBPLibrary(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}

float ULFsInteractionSystemBPLibrary::LFsInteractionSystemSampleFunction(float Param)
{
	return -1;
}

