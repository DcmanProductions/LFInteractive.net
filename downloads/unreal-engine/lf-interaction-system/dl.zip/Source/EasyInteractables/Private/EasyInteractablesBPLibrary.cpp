// All Rights Reserved - LFInteractive LLC (c) 2022

#include "EasyInteractablesBPLibrary.h"
#include "EasyInteractables.h"

UEasyInteractablesBPLibrary::UEasyInteractablesBPLibrary(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}

float UEasyInteractablesBPLibrary::EasyInteractablesSampleFunction(float Param)
{
	return -1;
}

