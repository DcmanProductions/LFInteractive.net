// LFInteractive LLC. All Rights Reserved

#include "LFSInteractionDemo.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, LFSInteractionDemo, "LFSInteractionDemo" );
